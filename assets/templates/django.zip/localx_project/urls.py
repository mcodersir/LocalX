from django.contrib import admin
from django.urls import path
from django.http import HttpResponse

def home(_request):
    return HttpResponse('Hello LocalX Django')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home),
]

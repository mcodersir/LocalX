<?php

echo 'Hello LocalX Laravel';

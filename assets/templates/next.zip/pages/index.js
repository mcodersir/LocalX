export default function Home() {
  return (
    <main style={{ fontFamily: 'sans-serif', padding: 24 }}>
      <h1>Hello LocalX Next.js</h1>
    </main>
  )
}

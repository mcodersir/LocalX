<template>
  <main style="font-family: sans-serif; padding: 24px;">
    <h1>Hello LocalX Nuxt</h1>
  </main>
</template>

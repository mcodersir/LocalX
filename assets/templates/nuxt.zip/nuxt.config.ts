export default defineNuxtConfig({})

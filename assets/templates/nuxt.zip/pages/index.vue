<template>
  <div>Hello LocalX Nuxt</div>
</template>

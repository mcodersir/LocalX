export default function App() {
  return (
    <main style={{ fontFamily: 'sans-serif', padding: 24 }}>
      <h1>Hello LocalX React</h1>
    </main>
  )
}

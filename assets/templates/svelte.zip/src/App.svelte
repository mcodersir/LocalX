<main class='app'>
  <h1>Hello LocalX Svelte</h1>
</main>
<style>
  .app { font-family: sans-serif; padding: 24px; }
</style>

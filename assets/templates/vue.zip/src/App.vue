<template>
  <main class="app">
    <h1>Hello LocalX Vue</h1>
  </main>
</template>
<style>
.app { font-family: sans-serif; padding: 24px; }
</style>

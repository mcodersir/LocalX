<?php

echo 'Hello LocalX WordPress (placeholder)';
